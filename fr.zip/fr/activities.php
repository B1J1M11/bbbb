<?php
/**
 * Activity text strings.
 * Is used for all the text within activity logs & notifications.
 */
return [

    // Pages = Action
    'page_create'                 => 'a créé l\'action',
    'page_create_notification'    => 'Action créée avec succès',
    'page_update'                 => 'a modifié l\'action',
    'page_update_notification'    => 'Action modifiée avec succès',
    'page_delete'                 => 'a supprimé l\'action',
    'page_delete_notification'    => 'Action supprimée avec succès',
    'page_restore'                => 'a restauré l\'action',
    'page_restore_notification'   => 'Action restaurée avec succès',
    'page_move'                   => 'a déplacé l\'action',
    'page_move_notification'      => 'Action déplacée avec succès',

    // Chapters = Projet
    'chapter_create'              => 'a créé le projet',
    'chapter_create_notification' => 'Projet créé avec succès',
    'chapter_update'              => 'a modifié le projet',
    'chapter_update_notification' => 'Projet modifié avec succès',
    'chapter_delete'              => 'a supprimé le projet',
    'chapter_delete_notification' => 'Projet supprimé avec succès',
    'chapter_move'                => 'a déplacé le projet',
    'chapter_move_notification' => 'Projet déplacé avec succès',

    // Books = Equipement
    'book_create'                 => 'a créé un équipement',
    'book_create_notification'    => 'Équipement créé avec succès',
    'book_create_from_chapter'              => 'Projet converti en équipement',
    'book_create_from_chapter_notification' => 'Projet converti en équipement avec succès',
    'book_update'                 => 'a modifié l\'équipement',
    'book_update_notification'    => 'Équipement modifié avec succès',
    'book_delete'                 => 'a supprimé un équipement',
    'book_delete_notification'    => 'Équipement supprimé avec succès',
    'book_sort'                   => 'a réordonné l\'équipement',
    'book_sort_notification'      => 'Équipement restauré avec succès',

    // Bookshelves = Produit
    'bookshelf_create'            => 'a créé le produit',
    'bookshelf_create_notification'    => 'Produit créé avec succès',
    'bookshelf_create_from_book'    => 'équipement converti en produit',
    'bookshelf_create_from_book_notification'    => 'Équipement converti en produit avec succès',
    'bookshelf_update'                 => 'produit mise à jour',
    'bookshelf_update_notification'    => 'Produit mise à jour avec succès',
    'bookshelf_delete'                 => 'produit supprimée',
    'bookshelf_delete_notification'    => 'Produit supprimée avec succès',

    // Revisions
    'revision_restore' => 'a restauré la révision',
    'revision_delete' => 'révision supprimée',
    'revision_delete_notification' => 'Révision supprimée avec succès',

    // Favourites
    'favourite_add_notification' => '":name" a été ajouté dans vos favoris',
    'favourite_remove_notification' => '":name" a été supprimé de vos favoris',

    // Watching
    'watch_update_level_notification' => 'Suivre les préférences mises à jour avec succès',

    // Auth
    'auth_login' => 'connecté',
    'auth_register' => 'enregistré en tant que nouvel utilisateur',
    'auth_password_reset_request' => 'demande de réinitialisation du mot de passe',
    'auth_password_reset_update' => 'réinitialisation du mot de passe',
    'mfa_setup_method' => 'méthode MFA configurée',
    'mfa_setup_method_notification' => 'Méthode multi-facteurs configurée avec succès',
    'mfa_remove_method' => 'méthode MFA supprimée',
    'mfa_remove_method_notification' => 'Méthode multi-facteurs supprimée avec succès',

    // Settings
    'settings_update' => 'paramètres mis à jour',
    'settings_update_notification' => 'Paramètres mis à jour avec succès',
    'maintenance_action_run' => 'exécuter l\'action de maintenance',

    // Webhooks
    'webhook_create' => 'Créer un Webhook',
    'webhook_create_notification' => 'Webhook créé avec succès',
    'webhook_update' => 'éditer un Webhook',
    'webhook_update_notification' => 'Webhook modifié avec succès',
    'webhook_delete' => 'supprimer un Webhook',
    'webhook_delete_notification' => 'Webhook supprimé avec succès',

    // Users
    'user_create' => 'utilisateur créé',
    'user_create_notification' => 'Utilisateur créé avec succès',
    'user_update' => 'utilisateur mis à jour',
    'user_update_notification' => 'Utilisateur mis à jour avec succès',
    'user_delete' => 'utilisateur supprimé',
    'user_delete_notification' => 'Utilisateur supprimé avec succès',

    // API Tokens
    'api_token_create' => 'jeton d\'api créé',
    'api_token_create_notification' => 'Jeton d\'API créé avec succès',
    'api_token_update' => 'jeton d\'api mis à jour',
    'api_token_update_notification' => 'Jeton d\'API mis à jour avec succès',
    'api_token_delete' => 'jeton d\'api supprimé',
    'api_token_delete_notification' => 'Jeton d\'API supprimé avec succès',

    // Roles
    'role_create' => 'rôle créé',
    'role_create_notification' => 'Rôle créé avec succès',
    'role_update' => 'rôle mis à jour',
    'role_update_notification' => 'Rôle mis à jour avec succès',
    'role_delete' => 'rôle supprimé',
    'role_delete_notification' => 'Rôle supprimé avec succès',

    // Recycle Bin
    'recycle_bin_empty' => 'corbeille vidée',
    'recycle_bin_restore' => 'restauré à partir de la corbeille',
    'recycle_bin_destroy' => 'supprimé de la corbeille',

    // Comments
    'commented_on'                => 'a commenté',
    'comment_create'              => 'Commentaire ajouté',
    'comment_update'              => 'Commentaire mis à jour',
    'comment_delete'              => 'Commentaire supprimé',

    // Other
    'permissions_update'          => 'a mis à jour les autorisations sur',
];
