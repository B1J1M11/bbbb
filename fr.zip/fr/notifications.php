<?php
/**
 * Text used for activity-based notifications.
 */
return [

    'new_comment_subject' => 'Nouveau commentaire sur l\'action : :pageName',
    'new_comment_intro' => 'Un utilisateur a commenté une action dans :appName:',
    'new_page_subject' => 'Nouvelle action : :pageName',
    'new_page_intro' => 'Une nouvelle action a été créée dans :appName:',
    'updated_page_subject' => 'Action mise à jour : :pageName',
    'updated_page_intro' => 'Une action a été mise à jour dans :appName:',
    'updated_page_debounce' => 'Pour éviter de nombreuses notifications, pendant un certain temps, vous ne recevrez pas de notifications pour d\'autres modifications de cette action par le même éditeur.',

    'detail_page_name' => 'Nom de l\'action :',
    'detail_commenter' => 'Commenta·teur·trice :',
    'detail_comment' => 'Commentaire :',
    'detail_created_by' => 'Créé par :',
    'detail_updated_by' => 'Mis à jour par :',

    'action_view_comment' => 'Voir le commentaire',
    'action_view_page' => 'Afficher l\'action',

    'footer_reason' => 'Cette notification vous a été envoyée car :link couvre ce type d\'activité pour cet élément.',
    'footer_reason_link' => 'vos préférences de notification',
];
